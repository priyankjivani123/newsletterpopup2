<?php

namespace Vdcstore\NewsletterPopup\Model;

class Cookie
{

    private $cookieManager;

    private $cookieMetadataFactory;

    public function __construct(
        \Magento\Framework\Stdlib\CookieManagerInterface       $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
    ) {
        $this->cookieManager = $cookieManager;
        $this->cookieMetadataFactory = $cookieMetadataFactory;
    }

    public function setCustomCookie()
    {
        $publicCookieMetadata = $this->cookieMetadataFactory->createPublicCookieMetadata();
        $publicCookieMetadata->setDurationOneYear();
        $publicCookieMetadata->setPath('/');
        $publicCookieMetadata->setHttpOnly(false);

        return $this->cookieManager->setPublicCookie(
            'newslattercookie',
            'cookiesetsucess',
            $publicCookieMetadata
        );
    }

    public function getCustomCookie()
    {
        return $this->cookieManager->getCookie(
            'newslattercookie'
        );
    }
}
